package ziegler.compiler;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Compiler {
	private char[] memory;

	public Compiler(String filename) throws FileNotFoundException {
		memory = new char[256];

		Scanner scanner = new Scanner(new File(filename));

		int i = 0;
		while (scanner.hasNext()) {
			String instruction = scanner.next();
			switch (instruction) {
				case "LD":
					memory[i] = '0';
					break;
				case "ST":
					memory[i] = '1';
					break;
				case "SWP":
					memory[i] = '2';
					break;
				case "ADD":
					memory[i] = '3';
					break;
				case "INC":
					memory[i] = '4';
					break;
				case "DEC":
					memory[i] = '5';
					break;
				case "BZ":
					memory[i] = '6';
					break;
				case "BR":
					memory[i] = '7';
					break;
				case "STP":
					memory[i] = '8';
					break;
				case "//":
					//do nothing - automatically goes to next line
					break;
				default:
					//invalid instruction
					System.exit(1);
			}

			// if two letter - then number following
			// if three letters - then just action
			if (instruction.length() == 2) {
				String hex = Integer.toHexString(scanner.nextInt()).toUpperCase();
				memory[++i] = hex.charAt(0);
				memory[++i] = hex.charAt(1);
			}
			
			if (scanner.hasNextLine()) {
				scanner.nextLine();
			}
			
			i++;
		}

		scanner.close();
	}

	public String toString() {
		// TODO go through whole array and print 0 if empty
		StringBuilder builder = new StringBuilder();
		for (char c : memory) {
			builder.append(c);
		}
		return builder.toString();
	}

	public static void main(String[] args) {
		try {
			Compiler compiler = new Compiler("compileInstructions");
			System.out.println(compiler.toString());
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}